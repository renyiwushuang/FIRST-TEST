﻿#ifndef CUSTORM_LABEL_H
#define CUSTORM_LABEL_H

#include <QLabel>

extern uint8_t set_led(QLabel* label, int color, int size);

#endif //CUSTORM_LABEL_H

